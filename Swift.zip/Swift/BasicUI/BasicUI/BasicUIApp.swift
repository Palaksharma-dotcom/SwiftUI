//
//  BasicUIApp.swift
//  BasicUI
//
//  Created by Rapipay on 14/02/23.
//

import SwiftUI

@main
struct BasicUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
