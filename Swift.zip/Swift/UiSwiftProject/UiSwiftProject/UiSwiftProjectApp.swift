//
//  UiSwiftProjectApp.swift
//  UiSwiftProject
//
//  Created by Rapipay on 13/02/23.
//

import SwiftUI

@main
struct UiSwiftProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
