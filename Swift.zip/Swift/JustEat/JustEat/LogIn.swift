//
//  LogIn.swift
//  JustEat
//
//  Created by Rapipay on 08/02/23.
//

import Foundation
import UIKit
class LogIn: UILabel{
    
    
    
}
